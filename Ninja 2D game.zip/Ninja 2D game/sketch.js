
//Positions
var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var realPos;

//Conditional Variables
var isLeft;
var isRight;
var isJumping;
var isFalling;
var isOnPlatform;

//Mechanics & Forces
var lift = -50;
var velocity = 0;
var gravity = 20;

//Items/Objects in the game
var clouds;
var mountains;
var trees;
var houseXs;
var canyons;
var coins;
var lives;
var enemies;
var platforms;

//Progress metrics
var score;
var isVictory;
var isLost;





function setup()
{
	createCanvas(1024, 576);
	floorPos_y = height * 3/4;
    startGame();
    lives = 3;
}

function startGame()
{
    gameChar_x = 50;
	gameChar_y = floorPos_y - 45;
    // Variable to control the background scrolling.
	scrollPos = 0;

	// Variable to store the real position of the gameChar in the game
	// world. Needed for collision detection.
	realPos = gameChar_x - scrollPos;

	// Boolean variables to control the movement of the game character.
	isLeft = false;
	isRight = false;
	isJumping = false;
	isFalling = false;
    isVictory = false;
    isLost = false;
    isOnPlatform = false;
    
    //Initial Score
    score = 0;

	// Initialise arrays of scenery objects.
    
    platforms = [];
    
    enemies = [];
    
    enemies.push(
    {
        x_pos: 670,
        y_pos: floorPos_y - 50,
        x1: 650,
        x2:780,
        speed: 2,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(200,150,110);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(225); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(0,120,255);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(225);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(200,150,110);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(225); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(0,120,255);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(225);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    },
        {
        x_pos: 1400,
        y_pos: floorPos_y - 50,
        x1: 1350,
        x2:1500,
        speed: 1.5,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(200,150,110);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(205,0,0); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(0,120,255);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(205,0,0);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(200,150,110);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(205,0,0); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(0,120,255);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(205,0,0);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    },
    {
        x_pos: 1800,
        y_pos: floorPos_y - 130,
        x1: 1750,
        x2:1950,
        speed: 1.2,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(200,150,110);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(115,0,115); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(255,255,0);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(115,0,115);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(200,150,110);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(115,0,115); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(255,255,0);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(115,0,115);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    },
    {
        x_pos: 2300,
        y_pos: floorPos_y - 50,
        x1: 2200,
        x2:2400,
        speed: 2,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(180,140,100);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(0,76,153); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(205,0,0);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(0,76,153);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(180,140,100);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(0,76,153); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(205,0,0);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(0,76,153);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    },
        {
        x_pos: 3500,
        y_pos: floorPos_y - 50,
        x1: 3400,
        x2:3550,
        speed: 3,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(180,140,100);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(0,120,0); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(245,245,10);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(0,120,0);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(180,140,100);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(0,120,0); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(245,245,10);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(0,120,0);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    },
    {
        x_pos: 4300,
        y_pos: floorPos_y - 50,
        x1: 4250,
        x2:4450,
        speed: 2.5,
        display: function()
                {
                    //Draw Enemy Ninja
                    if(this.speed > 0){
                        //Skin colour
                            fill(180,140,100);
                            ellipse(this.x_pos, this.y_pos, 45, 45); 
                        //Outfit colour
                            fill(255,128,0); 
                        //neck
                            rect(this.x_pos-4,this.y_pos+10,8,20);
                        //facemask bottom part
                            arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                        //facemask top part
                            arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                        //facemask left side
                            arc(this.x_pos, this.y_pos, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
                        //torso
                            triangle(this.x_pos-10, this.y_pos+25,
                                     this.x_pos+10,this.y_pos+25,
                                     this.x_pos,this.y_pos+40); 
                        //skirt
                            triangle(this.x_pos-7,this.y_pos+42,
                                     this.x_pos+7,this.y_pos+42,
                                     this.x_pos,this.y_pos+25);
                        //leg
                            rect(this.x_pos-2,this.y_pos+38,4,10);
                        //foot
                            arc(this.x_pos+3,this.y_pos+48,8,6,PI,0,CHORD);
                        //belt colour
                            fill(0,128,255);
                        //belt
                            quad(this.x_pos-4.2,this.y_pos+35.4,
                                 this.x_pos+4.2,this.y_pos+35.4,
                                 this.x_pos+5.4,this.y_pos+38,
                                 this.x_pos-5.4,this.y_pos+38);
                        //eye colour
                            stroke(0);
                            fill(255);
                        //eye
                            arc(this.x_pos+12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                        //outfit colour
                            fill(255,128,0);
                            noStroke();
                        //arm
                            rect(this.x_pos,this.y_pos+25,12,4);
                        //hand
                            ellipse(this.x_pos+14,this.y_pos+27,6,6);
                            noStroke();
                    }
                    else if(this.speed < 0)
                        {
                                //Skin colour
                                    fill(180,140,100);
                                    ellipse(this.x_pos, this.y_pos, 45, 45); 
                                //Outfit colour
                                    fill(255,128,0); 
                                //neck
                                    rect(this.x_pos-4,this.y_pos+10,8,20);
                                //facemask bottom part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI/8, PI - PI/8, CHORD);
                                //facemask top part
                                    arc(this.x_pos, this.y_pos, 45, 45, PI, 0, CHORD);
                                //facemask right side
                                    arc(this.x_pos, this.y_pos, 45, 45, PI * 3/2, PI/2, CHORD);
                                //torso
                                    triangle(this.x_pos-10, this.y_pos+25,
                                             this.x_pos+10,this.y_pos+25,
                                             this.x_pos,this.y_pos+40); 
                                //skirt
                                    triangle(this.x_pos-7,this.y_pos+42,
                                             this.x_pos+7,this.y_pos+42,
                                             this.x_pos,this.y_pos+25);
                                //leg
                                    rect(this.x_pos-2,this.y_pos+38,4,10);
                                //foot
                                    arc(this.x_pos-3,this.y_pos+48,8,6,PI,0,CHORD);
                                //belt colour
                                    fill(0,128,255);
                                //belt
                                    quad(this.x_pos-4.2,this.y_pos+35.4,
                                         this.x_pos+4.2,this.y_pos+35.4,
                                         this.x_pos+5.4,this.y_pos+38,
                                         this.x_pos-5.4,this.y_pos+38);
                                //eye colour
                                    stroke(0);
                                    fill(255);
                                //eye
                                    arc(this.x_pos-12,this.y_pos+4,10,7,0 - PI/8,PI+PI/8,CHORD);
                                //outfit colour
                                    fill(255,128,0);
                                    noStroke();
                                //arm
                                    rect(this.x_pos-14,this.y_pos+25,12,4);
                                //hand
                                    ellipse(this.x_pos-15,this.y_pos+27,6,6);
                                    noStroke();
                        }
                },
        move: function()
                {
                    this.x_pos += this.speed;

                    if(this.x_pos <= this.x1 || this.x_pos >= this.x2)
                    {
                        this.speed *= -1;
                    }
                },
        checkCharCollision: function()
                {
                     if(realPos > this.x_pos - 25 &&
                        realPos < this.x_pos + 25 &&
                        gameChar_y < this.y_pos + 30 &&
                        gameChar_y > this.y_pos - 30)
                        {
                            playerDied();
                        }
                }
    }
    );
    
    platforms.push(
    {
        x_pos: 130,
        y_pos: floorPos_y - 80,
        width: 200,
        height: 15,
        display: function()
        {
            // Draw platform.
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    },
        {
        x_pos: 235,
        y_pos: floorPos_y - 150,
        width: 70,
        height: 15,
            
        // Draw platform.
        display: function()
        {
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, 55);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, 55);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    },
        {
        x_pos: 925,
        y_pos: floorPos_y - 80,
        width: 300,
        height: 15,
        
        // Draw platform.
        display: function()
        {
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    },
    {
        x_pos: 975,
        y_pos: floorPos_y - 150,
        width: 200,
        height: 10,
        display: function()
        {
            // Draw platform.
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, 58);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, 58);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    },
    {
        x_pos: 1700,
        y_pos: floorPos_y - 80,
        width: 300,
        height: 15,
        display: function()
        {
            // Draw platform.
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, floorPos_y - this.y_pos -this.height);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    },
        {
        x_pos: 1775,
        y_pos: floorPos_y - 150,
        width: 150,
        height: 15,
        display: function()
        {
            // Draw platform.
            fill(139,69,19);
            rect(this.x_pos, this.y_pos, this.width, this.height);
            fill(109,49,19);
            rect(this.x_pos + this.width * 0.2 - this.height, this.y_pos + this.height,
                 this.height, 55);
            rect(this.x_pos + this.width * 0.8, this.y_pos + this.height,
                 this.height, 55);
            stroke(109,49,19);
            line(this.x_pos,
                 this.y_pos + this.height / 2,
                 this.x_pos + this.width,
                 this.y_pos + this.height / 2);
        },
        checkCharOn: function()
        {
            if( gameChar_y + 45 >= this.y_pos &&
                gameChar_y + 45 <= this.y_pos + this.height &&
                realPos >= this.x_pos &&
                realPos <= this.x_pos +this.width)
            {
                isOnPlatform = true;
            }
        }
    }
    )
    //initial cloud positions
    clouds = [];
    
    for(var i = 0; i < 100; i++)
    {
        clouds.push({
        pos_x: i * random(300,400),
        pos_y: random(floorPos_y - 350, floorPos_y - 400) });
    }
    
    mountains = [];
    
    for(var i = 0; i < 100; i++)
    {
        mountains.push({
            pos_x: i * random(100,300),    // random space between clouds
            h: random(200,320) // random heights 
        })
    }
    
    //Initial Tree positions
    trees = [];
    
    for(var i = 0; i < 100; i++)
    {
        trees.push(i * random(180,250));
    }
    
    //initial house positions
    houseXs = [];
    
    for(var i = 0; i < 100; i++)
    {
        houseXs.push(i * random(500,800));
    }
    
    //Coin Positions
    coins = [{x_pos: 190,  y_pos: 310, size: 50, isFound: false},
             {x_pos: 270,  y_pos: 220, size: 50, isFound: false},
             {x_pos: 600,  y_pos: 400, size: 50, isFound: false},
             {x_pos: 1070, y_pos: 150, size: 50, isFound: false},
             {x_pos: 1500, y_pos: 400, size: 50, isFound: false},
             {x_pos: 1840, y_pos: 200, size: 50, isFound: false},
             {x_pos: 2500, y_pos: 400, size: 50, isFound: false},
             {x_pos: 2900, y_pos: 320, size: 50, isFound: false},
             {x_pos: 3200, y_pos: 400, size: 50, isFound: false},
             {x_pos: 3500, y_pos: 320, size: 50, isFound: false},
             {x_pos: 3900, y_pos: 400, size: 50, isFound: false},
             {x_pos: 4300, y_pos: 320, size: 50, isFound: false},
             {x_pos: 4700, y_pos: 320, size: 50, isFound: false}
            ];
    
    //Canyon Positions
    canyons = [{x_pos: 400, width: 120},
              {x_pos: 800, width: 150},
              {x_pos: 1000, width: 140},
              {x_pos: 1200, width: 100},
              {x_pos: 1600, width: 100},
              {x_pos: 2000, width: 170},
              {x_pos: 2650, width: 150},
              {x_pos: 3000, width: 100},
              {x_pos: 3300, width: 80},
              {x_pos: 3600, width: 170},
              {x_pos: 4000, width: 190},
              {x_pos: 4500, width: 100},
              {x_pos: 4800, width: 100}];
}

function draw()
{
	background(100, 155, 255); // fill the sky blue

	noStroke();
	fill(0,155,0);
	rect(0, floorPos_y, width, height/4); // draw some green ground
    
    //Draw a Sun
    fill(255,218,64);
    ellipse(650,100,120,120);
    fill(255,218,64,150);
    ellipse(650,100,150,150);
    fill(255,218,64,100);
    ellipse(650,100,190,190);
    noFill();

	// Draw clouds.
    push();
    translate(scrollPos * 0.2,0);
    drawClouds();
    pop();

	// Draw mountains.
    push();
    translate(scrollPos * 0.5,0);
    drawMountains();
    pop();

	// Draw trees.
    push();
    translate(scrollPos * 0.7,0);
    drawTrees();
    pop();

	// Draw houses.
    push();
    translate(scrollPos * 0.9,0);
    drawHouses();
    pop();

	// Draw canyons.
    push();
    translate(scrollPos,0);
    for(var i = 0; i < canyons.length; i++)
    {
        drawCanyon(canyons[i]);
        checkCanyon(canyons[i]);
    }
    pop();

	// Draw pickup items.
    push();
    translate(scrollPos,0);
    for(var i = 0; i < coins.length; i++)
    {
        drawCoin(coins[i]);
        checkPickup(coins[i]);
    }
    pop();
    
    //Game termination
    checkVictory();
    checkPlayerDied();
    
    //Enemies
    push();
    translate(scrollPos,0);
    for(var i = 0; i < enemies.length; i++)
    {
        enemies[i].display();
        enemies[i].move();
        enemies[i].checkCharCollision();
    }
    pop();
    
    //Platforms
    push();
    translate(scrollPos,0);
    isOnPlatform = false;
    for(var i = 0; i < platforms.length; i++)
    {
        platforms[i].display();
        platforms[i].checkCharOn();
    }
    pop();

	// Draw game character.
	drawGameChar();
    
    //Instructional text
    push();
    translate(scrollPos * 0.3,0);
    stroke(0);
    strokeWeight(2);
    fill(255);
    textSize(15);
    text("Collect all the coins to reach the next level",150,50);
    pop();
    
    //Game Score
    stroke(0);
    strokeWeight(2);
    fill(255);
    textSize(30);
    text("Score  " + score, 20,35);
    text("Lives  ", 800,35);
    for(var i = 0; i < lives; i++)
    {
        fill(255,0,0);
        ellipse(900 + 40*i, 25,30,30);
    }
    
    
    if(isLost)
    {
        text("Game over", 470,height/2 - 50);
        text("You lost", 490,height/2);
        text("Press space to continue", 390,height/2 + 50);
    }
    
    if(isVictory)
    {
        text("Game over", 470,height/2 - 50);
        text("You won", 495,height/2);
        text("Press space to continue", 390,height/2 + 50);
    }
    noStroke();
    noFill();

	// Logic to make the game character move or the background scroll.
	if(isLeft)
	{
			if(gameChar_x > width * 0.2)
			{
					gameChar_x -= 5;
			}
			else
			{
					scrollPos += 5;
			}
	}

	if(isRight)
	{
			if(gameChar_x < width * 0.8)
			{
					gameChar_x  += 6;
			}
			else
			{
					scrollPos -= 6; // negative for moving against the background
			}
	}

	// Logic to make the game character rise and fall.
	if(gameChar_y < floorPos_y - 45 && isOnPlatform == false)
	{
			gameChar_y += 2;
			isJumping = true;
	}
	else
	{
			isJumping = false;
	}

	if(isFalling)
	{
            
            velocity += gravity;
            velocity *= 0.9;
            gameChar_y += velocity;
			//gameChar_y += 14;
	}

	// Update real position of gameChar for collision detection.
	realPos = gameChar_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed(){

		// console.log(keyCode);
		// console.log(key);
    if(isLost || isVictory)
    {
        if(key == ' ')
        {
            nextLevel();
        }
        return;
    }

	if(key == 'A' || keyCode == 37)
	{
			isLeft = true;
	}

	if(key == 'D' || keyCode == 39)
	{
			isRight = true;
	}

	if(key == ' ' || key == 'W' || keyCode == 38)
	{
			if(!isJumping)
			{
				gameChar_y -= 100;
                //velocity += lift;
			}
	}
}

function keyReleased(){

	if(key == 'A' || keyCode == 37)
	{
		isLeft = false;
	}

	if(key == 'D' || keyCode == 39)
	{
		isRight = false;
	}

}


// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar()
{
	// draw game character
        
    if(isLeft && isJumping)
    {
        // add your jumping-left code
        
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45); 
        //Outfit colour
            fill(70); 
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask right side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 3/2, PI/2, CHORD);
        //torso
            triangle(gameChar_x-10, gameChar_y+25,
                     gameChar_x+10,gameChar_y+25,
                     gameChar_x,gameChar_y+40); 
        //skirt
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,gameChar_y+25);
        //leg
            rect(gameChar_x-2,gameChar_y+38,4,10);
        //foot
            arc(gameChar_x-3,gameChar_y+48,8,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //belt
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //eye
            arc(gameChar_x-12,gameChar_y+4,10,7,0 - PI/8,PI+PI/8,CHORD);
        //outfit colour
            fill(70);
            stroke(50);
        //arm
            rect(gameChar_x-14,gameChar_y+25,12,4);
        //hand
            ellipse(gameChar_x-15,gameChar_y+27,6,6);
            noStroke();

    }
    else if(isRight && isJumping)
    {
        // add your jumping-right code
        
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45); 
        //Outfit colour
            fill(70); 
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask left side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
        //torso
            triangle(gameChar_x-10, gameChar_y+25,
                     gameChar_x+10,gameChar_y+25,
                     gameChar_x,gameChar_y+40); 
        //skirt
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,gameChar_y+25);
        //leg
            rect(gameChar_x-2,gameChar_y+38,4,10);
        //foot
            arc(gameChar_x+3,gameChar_y+48,8,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //belt
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //eye
            arc(gameChar_x+12,gameChar_y+4,10,7,0 - PI/8,PI+PI/8,CHORD);
        //outfit colour
            fill(70);
            stroke(50);
        //arm
            rect(gameChar_x,gameChar_y+25,12,4);
        //hand
            ellipse(gameChar_x+14,gameChar_y+27,6,6);
            noStroke();

    }
    else if(isLeft)
    {
        // add your walking left code
        
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45); 
        //Outfit colour
            fill(70); 
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask right side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 3/2, PI/2, CHORD);
        //torso
            triangle(gameChar_x-10, gameChar_y+25,
                     gameChar_x+10,gameChar_y+25,
                     gameChar_x,gameChar_y+40); 
        //skirt
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,gameChar_y+25);
        //leg
            rect(gameChar_x-2,gameChar_y+38,4,10);
        //foot
            arc(gameChar_x-3,gameChar_y+48,8,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //belt
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //eye
            arc(gameChar_x-12,gameChar_y+4,10,7,0,PI,CHORD);
        //outfit colour
            fill(70);
            stroke(50);
        //arm
            rect(gameChar_x-2.25,gameChar_y+25,4,12);
        //hand
            ellipse(gameChar_x,gameChar_y+36,6,6);
            noStroke();

    }
    else if(isRight)
    {
        // add your walking right code
        
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45); 
        //Outfit colour
            fill(70); 
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask left side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 1/2, PI + HALF_PI, CHORD);
        //torso
            triangle(gameChar_x-10, gameChar_y+25,
                     gameChar_x+10,gameChar_y+25,
                     gameChar_x,gameChar_y+40); 
        //skirt
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,gameChar_y+25);
        //leg
            rect(gameChar_x-2,gameChar_y+38,4,10);
        //foot
            arc(gameChar_x+3,gameChar_y+48,8,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //belt
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //eye
            arc(gameChar_x+12,gameChar_y+4,10,7,0,PI,CHORD);
        //outfit colour
            fill(70);
            stroke(50);
        //arm
            rect(gameChar_x-2.25,gameChar_y+25,4,12);
        //hand
            ellipse(gameChar_x,gameChar_y+36,6,6);
            noStroke();

    }
    else if(isJumping || isFalling)
    {
        // add your jumping facing forwards code
        
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45);
        //Outfit colour
            fill(70);
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask right side
            arc(gameChar_x, gameChar_y, 45, 45, PI + PI * 3/4, QUARTER_PI, CHORD);
        //facemask left side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 3/4, PI + QUARTER_PI, CHORD);
        //torso
            triangle(gameChar_x-15, gameChar_y+25,
                     gameChar_x+15,gameChar_y+25,
                     gameChar_x,gameChar_y+40);
        
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,gameChar_y+25);
        //left arm
            rect(gameChar_x-21,gameChar_y+25,10,4);
        //right arm
            rect(gameChar_x+10,gameChar_y+25,10,4);
        //left leg
            rect(gameChar_x-5,gameChar_y+38,4,10);
        //right leg
            rect(gameChar_x+1,gameChar_y+38,4,10);
        //left hand
            ellipse(gameChar_x-20,gameChar_y+27,6,6);
        //right hand
            ellipse(gameChar_x+21,gameChar_y+27,6,6);
        //left foot
            arc(gameChar_x-3,gameChar_y+48,6,6,PI,0,CHORD);
        //right foot
            arc(gameChar_x+3,gameChar_y+48,6,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //chest opening
            triangle(gameChar_x-4,gameChar_y+25,
                     gameChar_x+4,gameChar_y+25,
                     gameChar_x,gameChar_y+30);
        
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //left eye
            arc(gameChar_x-9,gameChar_y+4,10,7,0 - PI/8,PI+PI/8,CHORD);
        //right eye
            arc(gameChar_x+9,gameChar_y+4,10,7,0 - PI/8,PI+PI/8,CHORD);
            noStroke();
        

    }
    else
    {
        // add your standing front facing code
        
        //Ninja
        //Skin colour
            fill(255,224,189);
            ellipse(gameChar_x, gameChar_y, 45, 45); 
        //Outfit colour
            fill(70); 
        //neck
            rect(gameChar_x-4,gameChar_y+10,8,20);
        //facemask bottom part
            arc(gameChar_x, gameChar_y, 45, 45, PI/8, PI - PI/8, CHORD);
        //facemask top part
            arc(gameChar_x, gameChar_y, 45, 45, PI, 0, CHORD);
        //facemask right side
            arc(gameChar_x, gameChar_y, 45, 45, PI + PI * 3/4, QUARTER_PI, CHORD);
        //facemask left side
            arc(gameChar_x, gameChar_y, 45, 45, PI * 3/4, PI + QUARTER_PI, CHORD);
        //torso
            triangle(gameChar_x-15,gameChar_y+25,
                     gameChar_x+15,gameChar_y+25,
                     gameChar_x,   gameChar_y+40); 
        //skirt
            triangle(gameChar_x-7,gameChar_y+42,
                     gameChar_x+7,gameChar_y+42,
                     gameChar_x,  gameChar_y+25);
        //left arm
            rect(gameChar_x-14,gameChar_y+25,4,12);
        //right arm
            rect(gameChar_x+10,gameChar_y+25,4,12);
        //left leg
            rect(gameChar_x-5,gameChar_y+38,4,10);
        //right leg
            rect(gameChar_x+1,gameChar_y+38,4,10);
        //left hand
            ellipse(gameChar_x-12,gameChar_y+36,6,6);
        //right hand
            ellipse(gameChar_x+12,gameChar_y+36,6,6);
        //left food
            arc(gameChar_x-3,gameChar_y+48,6,6,PI,0,CHORD);
        //right foot
            arc(gameChar_x+3,gameChar_y+48,6,6,PI,0,CHORD);
        //belt colour
            fill(255,0,0);
        //chest opening
            triangle(gameChar_x-4,gameChar_y+25,
                     gameChar_x+4,gameChar_y+25,
                     gameChar_x,  gameChar_y+30);
        //belt
            quad(gameChar_x-4.2,gameChar_y+35.4,
                 gameChar_x+4.2,gameChar_y+35.4,
                 gameChar_x+5.4,gameChar_y+38,
                 gameChar_x-5.4,gameChar_y+38);
        //eye colour
            stroke(0);
            fill(255);
        //left eye
            arc(gameChar_x-9,gameChar_y+4,10,7,0,PI,CHORD);
        //right eye
            arc(gameChar_x+9,gameChar_y+4,10,7,0,PI,CHORD);
            noStroke();

    }
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.
function drawClouds()
{
    for(var i = 0; i < clouds.length; i++)
        {
            noStroke();
            fill(210);
            ellipse(clouds[i].pos_x + 290,clouds[i].pos_y + 80,100,70);
            fill(200);
            ellipse(clouds[i].pos_x + 260,clouds[i].pos_y + 120,80,60);
            fill(220);
            ellipse(clouds[i].pos_x + 150,clouds[i].pos_y,80,50);
            fill(210);
            ellipse(clouds[i].pos_x + 230,clouds[i].pos_y + 80,120,90);
            fill(215);
            ellipse(clouds[i].pos_x + 190,clouds[i].pos_y + 30,90,70);
            fill(210);
            ellipse(clouds[i].pos_x + 100,clouds[i].pos_y + 80,120,90);
            fill(215);
            ellipse(clouds[i].pos_x + 120,clouds[i].pos_y + 30,90,70);
            fill(190);
            ellipse(clouds[i].pos_x + 190,clouds[i].pos_y + 130,90,70);
            fill(195);
            ellipse(clouds[i].pos_x + 120,clouds[i].pos_y + 130,90,70);
            fill(210);
            ellipse(clouds[i].pos_x + 150,clouds[i].pos_y + 80,130,110);
        }
}

// Function to draw mountains objects.
function drawMountains()
{
    for(var i = 0; i < mountains.length; i++)
        {
//            console.log(mountains[i]);
    fill(118,118,165);
    triangle
           (mountains[i].pos_x, floorPos_y - mountains[i].h,
            mountains[i].pos_x - 200, floorPos_y, 
            mountains[i].pos_x + 200, floorPos_y);
    fill(10,10,10,50);
    triangle
            (mountains[i].pos_x, floorPos_y - mountains[i].h,
             mountains[i].pos_x - 110, floorPos_y, 
             mountains[i].pos_x - 200, floorPos_y);
        }
}

// Function to draw trees objects.
function drawTrees ()
{
    for(var i = 0; i < trees.length; i++)
        {
        //Tree trunk
            fill(139,69,19);
            rect(trees[i]+120,floorPos_y - 110,20,110);
        //Tree trunk base
            triangle(trees[i]+160,floorPos_y,
                     trees[i]+128,floorPos_y - 20,
                     trees[i]+128,floorPos_y);
            fill(119,59,19);
        //Tree trunk
            rect(trees[i]+120,floorPos_y - 110,8,110);
        //Tree trunk base
            triangle(trees[i]+100,floorPos_y,
                     trees[i]+128,floorPos_y - 20,
                     trees[i]+128,floorPos_y);
        //The top of the tree
            fill(10,150,10);
            ellipse(trees[i]+100,floorPos_y - 100, 80,80);
            ellipse(trees[i]+160,floorPos_y - 100, 80,80);
            fill(10,170,10);
            ellipse(trees[i]+100,floorPos_y - 107, 80,65);
            ellipse(trees[i]+160,floorPos_y - 107, 80,65);
            fill(10,150,10);
            ellipse(trees[i]+130,floorPos_y - 160, 80,80);
            fill(10,170,10);
            ellipse(trees[i]+130,floorPos_y - 167, 80,65);
        }
}

// Function to draw houses objects.
function drawHouses()
{
    for(var i = 0; i < houseXs.length; i++)
        {   
            //side of the house
            noStroke();
            fill(183,134,11);
            rect(houseXs[i] -20,floorPos_y - 60,120,60);

            //front of the house

            fill(218,165,32);
            beginShape();
                vertex(houseXs[i] +100,floorPos_y - 60);
                vertex(houseXs[i] +125,floorPos_y - 100);
                vertex(houseXs[i] +150,floorPos_y - 100);
                vertex(houseXs[i] +175,floorPos_y - 140);
                vertex(houseXs[i] +150,floorPos_y - 140);
                vertex(houseXs[i] +200,floorPos_y - 140);
                vertex(houseXs[i] +220,floorPos_y - 100);
                vertex(houseXs[i] +240,floorPos_y - 100);
                vertex(houseXs[i] +260,floorPos_y - 60);
                vertex(houseXs[i] +260,floorPos_y);
                vertex(houseXs[i] +100,floorPos_y);
            endShape(CLOSE);

            //The roof

            fill(140,70,50);
            quad(houseXs[i] -20, floorPos_y - 60,
                 houseXs[i] +5,  floorPos_y - 100,
                 houseXs[i] +125,floorPos_y - 100,
                 houseXs[i] +100,floorPos_y - 60);

            quad(houseXs[i] +30,floorPos_y - 100,
                 houseXs[i] +55,floorPos_y - 140,
                 houseXs[i] +175,floorPos_y - 140,
                 houseXs[i] +150,floorPos_y - 100);

            //Edges of the roof (On the right side)

            strokeWeight(5);
            stroke(140,70,50);    
            line(houseXs[i] +57,floorPos_y - 140,
                 houseXs[i] +198,floorPos_y - 140);
            strokeWeight(3);
            line(houseXs[i] +200,floorPos_y - 141,
                 houseXs[i] +219,floorPos_y - 101);
            line(houseXs[i] +220,floorPos_y - 100,
                 houseXs[i] +238,floorPos_y -100);
            line(houseXs[i] +240,floorPos_y - 100,
                 houseXs[i] +259,floorPos_y - 61); 

            //The door

            fill(139,69,19);
            stroke(110,49,19);
            rect(houseXs[i] +175,floorPos_y - 50,25,45);

            //The windows

            fill(10,208,129);
            stroke(110,49,19);
            rect(houseXs[i] , floorPos_y - 40,20,15);
            rect(houseXs[i] +50,floorPos_y - 40,20,15);
            rect(houseXs[i] +128,floorPos_y - 40,20,15);
            rect(houseXs[i] +222,floorPos_y - 40,20,15);
            rect(houseXs[i] +140,floorPos_y - 85,15,15);
            rect(houseXs[i] +215,floorPos_y - 85,15,15);
            rect(houseXs[i] +180,floorPos_y - 125,15,15);
            noStroke();
        }
}


// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon)
{
    fill(50,50,0);
    rect(t_canyon.x_pos, floorPos_y, t_canyon.width, height - floorPos_y);
}

// Function to check character is over a canyon.

function checkCanyon(t_canyon)
{
    if(realPos > t_canyon.x_pos && 
       realPos < t_canyon.x_pos + t_canyon.width && 
       gameChar_y >= floorPos_y - 50 &&
       isOnPlatform == false)
    {
        isFalling = true;
    }
}

// ----------------------------------
// Pick-up render and check functions
// ----------------------------------

// Function to draw pick-up objects.
function drawCoin(t_coin)
{
    if(!t_coin.isFound)
        {
    //side of the coin
            fill(255,205,0);
            ellipse(t_coin.x_pos + 5, t_coin.y_pos,
                    t_coin.size - 25,t_coin.size + 5);
        //face of the coin
            fill(255,235,0);
            noStroke();
            ellipse(t_coin.x_pos, t_coin.y_pos, 
                    t_coin.size - 25,t_coin.size + 5);
        //inner circle
            noFill();
            strokeWeight(2);
            stroke(255,215,0);
            ellipse(t_coin.x_pos, t_coin.y_pos, 
                    t_coin.size - 30,t_coin.size);
            noStroke();
        }
}

// Function to check character has picked up an item.
function checkPickup(t_coin)
{
    if(realPos < t_coin.x_pos + 13 && 
       realPos > t_coin.x_pos - 13 && 
       gameChar_y > t_coin.y_pos - 30 && 
       gameChar_y < t_coin.y_pos + 30)
    {   
        if(!t_coin.isFound){
            t_coin.isFound = true; // detecting when the character is withing the bounds of the coin
            score += 1;
        }
    }
}

function checkVictory()
{
    if(score == coins.length)
        {
            isVictory = true;
        }
}

function checkPlayerDied()
{
    if(gameChar_y > height)
    {
        playerDied();
    }
}
function playerDied()
{
    console.log('player died!');
    lives--;
    if (lives > 0)
    {
        // Restart game.
        startGame();
    }
    else
    {
        // Game over, player lost.
        isLost = true;
    }
}

function nextLevel()
{
    console.log('next level');
}
